package net.aya.angular.entities;

public enum AccountStatus {
    CREATED, ACTIVATED, SUSPENDED
}
