package net.aya.angular.dtos;

import lombok.Data;
import net.aya.angular.entities.AccountStatus;

import java.util.Date;
import java.util.List;

@Data
public class currentBankAccountDTO extends BankAccountDTO {
    private String id;
    private double balance;
    private Date createdAt;
    private AccountStatus status;
    private custumorDTO customerDTO;
    private double overDraft;

}