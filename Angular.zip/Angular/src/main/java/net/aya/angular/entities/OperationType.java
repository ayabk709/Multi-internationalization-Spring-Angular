package net.aya.angular.entities;

public enum OperationType {
   CREDIT, DEBIT
}
