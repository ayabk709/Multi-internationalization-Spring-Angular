Part1

1-![img.png](img/img.png)
2-
savingaccount
![img_1.png](img/img_1.png)
operationtype
![img_2.png](img/img_2.png)
accountstatus
![img_3.png](img/img_3.png)
Current account
![img_4.png](img/img_4.png)
custumor
![img_5.png](img/img_5.png)
operation
![img_6.png](img/img_6.png)
bankaccount
![img_7.png](img/img_7.png)
partie properties
![img_8.png](img/img_8.png)
3-
![img_12.png](img/img_12.png)
![img_13.png](img/img_13.png)
![img_14.png](img/img_14.png)
4-Test
![img_15.png](img/img_15.png)
![img_16.png](img/img_16.png)
<h2>dans H2</h2>
bankaccount
![img_9.png](img/img_9.png)
custumor
![img_10.png](img/img_10.png)
operation 
![img_11.png](img/img_11.png)
Avec SQL
partie properties
![img_17.png](img/img_17.png)
exec
![img_18.png](img/img_18.png)
bdd
![img_19.png](img/img_19.png)

<h1>Partie2</h1>
couche service

![img_20.png](img/img_20.png)
![img_21.png](img/img_21.png)
![img_22.png](img/img_22.png)
![img_23.png](img/img_23.png)
![img_24.png](img/img_24.png)

 RestController(WEB)

![img_25.png](img/img_25.png)
![img_26.png](img/img_26.png)
![img_27.png](img/img_27.png)

DTO
![img_28.png](img/img_28.png)
mappers
![img_30.png](img/img_30.png)
![img_31.png](img/img_31.png)
TEST
![img_32.png](img/img_32.png)



